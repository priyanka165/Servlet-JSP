
SQL> create table Course (courseId  number(4) primary key , courseName varchar2(25) 
	 not null ,courseDuration number(3) not null);

Table created.
