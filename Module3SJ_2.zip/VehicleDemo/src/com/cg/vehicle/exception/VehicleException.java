package com.cg.vehicle.exception;

public class VehicleException extends Exception{

	public VehicleException(String message) {
		super(message);
	}
}
