package com.cg.vehicle.dao;

import java.util.ArrayList;

import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;

public interface IVehicleDao {
	public int insertVehicle(Vehicle vehicle) throws VehicleException;
	public ArrayList<Vehicle> showVehicles() throws VehicleException;
}
