package com.cg.vehicle.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;
import com.cg.vehicle.util.DBUtil;

public class VehicleDaoImpl implements IVehicleDao {

	Connection connection = null;
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;

	@Override
	public int insertVehicle(Vehicle vehicle) throws VehicleException {
		connection = DBUtil.obtainConnection();
		String sql = "INSERT INTO Vehicle(vehicleid,vehicle_name,purchase_date,price,city) VALUES(Vehicle_SEQ.nextval,?,?,?,?)";
		int recordInserted = 0;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, vehicle.getVehicleName());
			preparedStatement.setDate(2,java.sql.Date.valueOf(vehicle.getPurchaseDate()));
			preparedStatement.setFloat(3, vehicle.getPrice());
			preparedStatement.setString(4, vehicle.getCity());

			recordInserted = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			
			throw new VehicleException("Error while inserting values::"
					+ e.getMessage());
		}
		return recordInserted;
	}

	@Override
	public ArrayList<Vehicle> showVehicles() throws VehicleException {
		ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
		connection = DBUtil.obtainConnection();
		String sql = "SELECT vehicleid,vehicle_name,purchase_date,price,city FROM Vehicle";
		try {
			statement = connection.createStatement();
			rsSet = statement.executeQuery(sql);
			while (rsSet.next()) {
				Vehicle vehicle = new Vehicle();
				vehicle.setVehicleId(rsSet.getInt("VEHICLEID"));
				vehicle.setVehicleName(rsSet.getString("VEHICLE_NAME"));
				vehicle.setPurchaseDate(rsSet.getDate("PURCHASE_DATE")
						.toLocalDate());
				vehicle.setPrice(rsSet.getFloat("PRICE"));
				vehicle.setCity(rsSet.getString("CITY"));

				vehicleList.add(vehicle);
			}
		} catch (SQLException e) {
			throw new VehicleException("Error while fetching values::"
					+ e.getMessage());
		}
		return vehicleList;

	}

}
