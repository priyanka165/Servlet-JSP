package com.cg.vehicle.service;

import java.util.ArrayList;
import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;

public interface IVehicleService {
	public int insertVehicle(Vehicle vehicle) throws VehicleException;
	public ArrayList<Vehicle> showVehicles() throws VehicleException;
}
