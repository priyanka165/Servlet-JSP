package com.cg.vehicle.service;

import java.util.ArrayList;

import com.cg.vehicle.dao.IVehicleDao;
import com.cg.vehicle.dao.VehicleDaoImpl;
import com.cg.vehicle.dto.Vehicle;
import com.cg.vehicle.exception.VehicleException;

public class VehicleServiceImpl implements IVehicleService {

	IVehicleDao vehicleDAO;
	
	public VehicleServiceImpl() {
		vehicleDAO=new VehicleDaoImpl();
	}

	@Override
	public int insertVehicle(Vehicle vehicle) throws VehicleException {
		return vehicleDAO.insertVehicle(vehicle);
	}

	@Override
	public ArrayList<Vehicle> showVehicles() throws VehicleException {
		return vehicleDAO.showVehicles();
	}

}
