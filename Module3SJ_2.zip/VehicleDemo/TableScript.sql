CREATE SEQUENCE Vehicle_SEQ;

CREATE TABLE Vehicle(VehicleID number primary key,Vehicle_Name varchar2(50)
,purchase_date date,price number(15,2),city varchar2(20));

INSERT INTO Vehicle(vehicleid,vehicle_name,purchase_date,price,city) VALUES
(Vehicle_SEQ.nextval,'Lamborghini','01-Dec-2015',20000000,'Bangalore');

INSERT INTO Vehicle(vehicleid,vehicle_name,purchase_date,price,city) VALUES
(Vehicle_SEQ.nextval,'Range Rover','10-Jan-2017',8000000,'Pennsylvania');

commit;