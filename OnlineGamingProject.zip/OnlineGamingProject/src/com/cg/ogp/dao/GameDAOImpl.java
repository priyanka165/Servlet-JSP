/**************************************************************
File Name   : ShowDAOImpl.java
Author      : Vinayak Kanase.
Description : Performin various operation on database
 ***************************************************************/
package com.cg.ogp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ogp.bean.GameDetails;
import com.cg.ogp.exception.GamingException;
import com.cg.ogp.util.DBUtil;

/*******************************************************************************************************
- Class Name		:	GameDAOImpl 
- Author			:	Priyanka D
- Creation Date	    :	11/12/2017
- Description		:	Dao implementation
********************************************************************************************************/

public class GameDAOImpl implements IGameDAO {
	Connection con;
	Statement stm;
	PreparedStatement pstm;
	ResultSet res;
	
/*******************************************************************************************************
 - Function Name	:	getGameDetails()
 - Input Parameters	:	NA
 - Return Type		:	list
 - Throws			:  	GamingException
 - Author			:	Priyanka D
 - Creation Date	:	11/12/2017
 - Description		:	listing game details
********************************************************************************************************/
	
	@Override
	public List<GameDetails> getGameDetails() throws GamingException {
		List<GameDetails> showDetailsList = new ArrayList<GameDetails>();
		try {
			con = DBUtil.getConnection();
			stm = con.createStatement();
			res = stm.executeQuery("select * from Game");
			while (res.next()) {
				GameDetails show = new GameDetails();
				show.setGameId(res.getString(1));
				show.setGameName(res.getString(2));
				show.setAvailableGames(res.getInt(3));
				show.setPrice(res.getDouble(4));
				showDetailsList.add(show);
			}
		} catch (SQLException e) {
			// e.printStackTrace();
			throw new GamingException(
					"Something went wrong while fetching gameDetails");
		} finally {
			try {
				res.close();
				stm.close();
				con.close();
			} catch (SQLException e) {
				// e.printStackTrace();
				throw new GamingException("SQLException occurred");
			}
		}
		return showDetailsList;
	}

	
/*******************************************************************************************************
 - Function Name	:	getGameDetail(String gameId)
 - Input Parameters	:	String gameId
 - Return Type		:	String
 - Throws			:  	GamingException
 - Author			:	Priyanka D
 - Creation Date	:	11/12/2017
 - Description		:	Getting game details
********************************************************************************************************/
	
	@Override
	public GameDetails getGameDetail(String gameId) throws GamingException {
		GameDetails show = null;
		try {
			con = DBUtil.getConnection();
			pstm = con.prepareStatement("select * from Game where GameId=?");
			pstm.setString(1, gameId);
			res = pstm.executeQuery();
			res.next();
			show = new GameDetails();
			show.setGameId(res.getString(1));
			show.setGameName(res.getString(2));
			show.setAvailableGames(res.getInt(3));
			show.setPrice(res.getDouble(4));

		} catch (SQLException e) {
			// e.printStackTrace();
			throw new GamingException("Problem while fetching show details");
		} finally {
			try {
				res.close();
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// e.printStackTrace();
				throw new GamingException("SQLException occurred");
			}

		}
		return show;
	}

	
/*******************************************************************************************************
 - Function Name	:	updateGameDetails(int games, String gamename)
 - Input Parameters	:	int games, String gamename
 - Return Type		:	void
 - Throws			:  	GamingException
 - Author			:	Priyanka D
 - Creation Date	:	11/12/2017
 - Description		:	Updating game details
********************************************************************************************************/
	
	@Override
	public void updateGameDetails(int games, String gamename)
			throws GamingException {
		try {
			con = DBUtil.getConnection();
			pstm = con
					.prepareStatement("update Game set Available_game = ? where GameName = ?");
			pstm.setInt(1, games);
			pstm.setString(2, gamename);
			pstm.executeUpdate();
		} catch (SQLException e) {
			// e.printStackTrace();
			throw new GamingException("Problem while updating the table");
		}

	}

}
