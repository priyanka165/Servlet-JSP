package com.cg.ogp.bean;

public class GameDetails {
	private String gameId;
	private String gameName;
	private int availableGames;
	private double price;

	public GameDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GameDetails(String gameId, String gameName, int availableGames,
			double price) {
		super();
		this.gameId = gameId;
		this.gameName = gameName;
		this.availableGames = availableGames;
		this.price = price;
	}

	public String getGameId() {
		return gameId;
	}

	public void setGameId(String gameId) {
		this.gameId = gameId;
	}

	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public int getAvailableGames() {
		return availableGames;
	}

	public void setAvailableGames(int availableGames) {
		this.availableGames = availableGames;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "GameDetails [gameId=" + gameId + ", gameName=" + gameName
				+ ", availableGames=" + availableGames + ", price=" + price
				+ "]";
	}

	/*
	 * @Override public int hashCode() { final int prime = 31; int result = 1;
	 * result = prime * result + ((showId == null) ? 0 : showId.hashCode());
	 * return result; }
	 * 
	 * @Override public boolean equals(Object obj) { if (this == obj) return
	 * true; if (obj == null) return false; if (getClass() != obj.getClass())
	 * return false; ShowDetails other = (ShowDetails) obj; if (showId == null)
	 * { if (other.showId != null) return false; } else if
	 * (!showId.equals(other.showId)) return false; return true; }
	 */
}
