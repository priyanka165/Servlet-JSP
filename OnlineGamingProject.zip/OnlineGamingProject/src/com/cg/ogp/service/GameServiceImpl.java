package com.cg.ogp.service;

import java.util.List;

import com.cg.ogp.bean.GameDetails;
import com.cg.ogp.dao.IGameDAO;
import com.cg.ogp.dao.GameDAOImpl;
import com.cg.ogp.exception.GamingException;

/*******************************************************************************************************
- Class Name		:	GameServiceImpl 
- Author			:	Priyanka D
- Creation Date	    :	11/12/2017
- Description		:	Service implementation
********************************************************************************************************/

public class GameServiceImpl implements IGameService 
{
	IGameDAO showDAO ;
	
	public GameServiceImpl()
	{
		showDAO = new GameDAOImpl();
	}
	
	
/*******************************************************************************************************
 - Function Name	:	getGameDetails()
 - Input Parameters	:	NA
 - Return Type		:	list
 - Throws			:  	GamingException
 - Author			:	Priyanka D
 - Creation Date	:	11/12/2017
 - Description		:	listing game details
********************************************************************************************************/
	
	@Override
	public List<GameDetails> getGameDetails() throws GamingException {
		// TODO Auto-generated method stub
		return showDAO.getGameDetails();
	}

/*******************************************************************************************************
 - Function Name	:	getGameDetail(String showid)
 - Input Parameters	:	String showid
 - Return Type		:	String
 - Throws			:  	GamingException
 - Author			:	Priyanka D
 - Creation Date	:	11/12/2017
 - Description		:	Getting game details by ID
********************************************************************************************************/
	
	@Override
	public GameDetails getGameDetail(String showid) throws GamingException {
		// TODO Auto-generated method stub
		return showDAO.getGameDetail(showid);
	}

/*******************************************************************************************************
 - Function Name	:	updateGameDetails(int games, String gamename)
 - Input Parameters	:	int games, String gamename
 - Return Type		:	void
 - Throws			:  	GamingException
 - Author			:	Priyanka D
 - Creation Date	:	11/12/2017
 - Description		:	Updating game details
********************************************************************************************************/
	
	@Override
	public void updateGameDetails(int games, String gamename)
			throws GamingException {
		// TODO Auto-generated method stub
		showDAO.updateGameDetails(games , gamename);
	}

}
